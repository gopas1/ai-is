# Airline and Cargo Scheduling Expert System (Mini Project)

This is a ready-to-run AI mini-project prototype implementing an expert system for combined airline flight scheduling and cargo allocation.

## What this prototype includes

- Rule-driven flight assignment (aircraft + crew)
- Rule-driven cargo assignment with business priorities
- Hard constraints: maintenance, overlap, turnaround, crew duty hours, capacity, deadlines
- Decision trace explaining which rules fired for each assignment
- KPI output for submission: feasibility, fulfillment, utilization, unassigned entities

## Rule base in the prototype

### Flight assignment rules

- R1: Aircraft type must match flight requirement
- R2: Aircraft must be route-qualified
- R3: Flight must not overlap aircraft maintenance window
- R4: Resource overlap and turnaround constraints must be satisfied
- R5: Best aircraft chosen by penalty score
- R6: Crew must be aircraft-qualified
- R7: Crew must be available (no overlap)
- R8: Crew projected duty hours must remain within limit
- R9: Crew balancing heuristic for fair allocation

### Cargo assignment rules

- R10: Emergency/perishable orders get higher priority
- R11: Standard queue processing for normal cargo
- R12: Cargo route must match candidate flight route
- R13: Flight arrival must meet cargo deadline
- R14: Remaining aircraft capacity must be enough
- R15: Prefer minimal slack + better capacity fit

## How to run

From project folder:

```powershell
python main.py
```

Optional custom paths:

```powershell
python main.py --data data/sample_data.json --out outputs/schedule_report.json
```

## Project structure

- `main.py`: full expert system implementation
- `data/sample_data.json`: realistic sample dataset
- `outputs/schedule_report.json`: generated report after run

## Suggested submission screenshots

- Console report summary with KPI metrics
- Flight assignment lines from console output
- JSON report section showing decision_trace

## Viva-ready explanation

Why expert system: scheduling requires strict, explainable, auditable rule compliance under operational constraints. Rule-based inference is a good fit where hard constraints matter more than black-box prediction.
