from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple


TIME_FMT = "%Y-%m-%d %H:%M"
PRIORITY_MAP = {"emergency": 0, "perishable": 1, "express": 2, "standard": 3}


@dataclass
class Aircraft:
    id: str
    type: str
    capacity_kg: int
    base_airport: str
    qualified_routes: List[str]
    maintenance_windows: List[Tuple[datetime, datetime]]


@dataclass
class Crew:
    id: str
    name: str
    qualifications: List[str]
    max_duty_hours: int


@dataclass
class Flight:
    id: str
    origin: str
    destination: str
    departure: datetime
    arrival: datetime
    required_aircraft_type: str
    assigned_aircraft: Optional[str] = None
    assigned_crew: Optional[str] = None
    cargo_manifest: List[str] = field(default_factory=list)
    cargo_weight_kg: int = 0


@dataclass
class CargoOrder:
    id: str
    origin: str
    destination: str
    weight_kg: int
    priority: str
    deadline: datetime
    assigned_flight: Optional[str] = None


@dataclass
class Decision:
    step: str
    entity_id: str
    outcome: str
    rules_fired: List[str]


class ExpertScheduler:
    def __init__(self, raw_data: Dict):
        self.aircraft: Dict[str, Aircraft] = {}
        self.crews: Dict[str, Crew] = {}
        self.flights: Dict[str, Flight] = {}
        self.cargo_orders: Dict[str, CargoOrder] = {}
        self.decisions: List[Decision] = []
        self.unassigned_flights: List[str] = []
        self.unassigned_cargo: List[str] = []

        self._load(raw_data)

    def _load(self, raw_data: Dict) -> None:
        for a in raw_data.get("aircraft", []):
            windows = []
            for w in a.get("maintenance_windows", []):
                windows.append((self._dt(w["start"]), self._dt(w["end"])))
            self.aircraft[a["id"]] = Aircraft(
                id=a["id"],
                type=a["type"],
                capacity_kg=a["capacity_kg"],
                base_airport=a["base_airport"],
                qualified_routes=a.get("qualified_routes", []),
                maintenance_windows=windows,
            )

        for c in raw_data.get("crews", []):
            self.crews[c["id"]] = Crew(
                id=c["id"],
                name=c["name"],
                qualifications=c.get("qualifications", []),
                max_duty_hours=c["max_duty_hours"],
            )

        for f in raw_data.get("flights", []):
            self.flights[f["id"]] = Flight(
                id=f["id"],
                origin=f["origin"],
                destination=f["destination"],
                departure=self._dt(f["departure"]),
                arrival=self._dt(f["arrival"]),
                required_aircraft_type=f["required_aircraft_type"],
            )

        for o in raw_data.get("cargo_orders", []):
            self.cargo_orders[o["id"]] = CargoOrder(
                id=o["id"],
                origin=o["origin"],
                destination=o["destination"],
                weight_kg=o["weight_kg"],
                priority=o["priority"],
                deadline=self._dt(o["deadline"]),
            )

    @staticmethod
    def _dt(value: str) -> datetime:
        return datetime.strptime(value, TIME_FMT)

    def run(self) -> Dict:
        self.schedule_flights()
        self.allocate_cargo()
        return self.build_report()

    def schedule_flights(self) -> None:
        aircraft_timeline: Dict[str, List[Tuple[datetime, datetime, str]]] = {aid: [] for aid in self.aircraft}
        crew_timeline: Dict[str, List[Tuple[datetime, datetime, str]]] = {cid: [] for cid in self.crews}

        flights_sorted = sorted(self.flights.values(), key=lambda x: x.departure)
        for flight in flights_sorted:
            aircraft_choice, aircraft_rules = self._choose_aircraft(flight, aircraft_timeline)
            if not aircraft_choice:
                self.unassigned_flights.append(flight.id)
                self.decisions.append(
                    Decision(
                        step="flight_assignment",
                        entity_id=flight.id,
                        outcome="rejected_no_aircraft",
                        rules_fired=aircraft_rules,
                    )
                )
                continue

            crew_choice, crew_rules = self._choose_crew(flight, aircraft_choice, crew_timeline)
            if not crew_choice:
                self.unassigned_flights.append(flight.id)
                self.decisions.append(
                    Decision(
                        step="flight_assignment",
                        entity_id=flight.id,
                        outcome=f"rejected_no_crew_after_aircraft_{aircraft_choice.id}",
                        rules_fired=aircraft_rules + crew_rules,
                    )
                )
                continue

            flight.assigned_aircraft = aircraft_choice.id
            flight.assigned_crew = crew_choice.id
            aircraft_timeline[aircraft_choice.id].append((flight.departure, flight.arrival, flight.id))
            crew_timeline[crew_choice.id].append((flight.departure, flight.arrival, flight.id))
            self.decisions.append(
                Decision(
                    step="flight_assignment",
                    entity_id=flight.id,
                    outcome=f"assigned_aircraft_{aircraft_choice.id}_crew_{crew_choice.id}",
                    rules_fired=aircraft_rules + crew_rules,
                )
            )

    def _choose_aircraft(
        self,
        flight: Flight,
        aircraft_timeline: Dict[str, List[Tuple[datetime, datetime, str]]],
    ) -> Tuple[Optional[Aircraft], List[str]]:
        candidates: List[Tuple[int, Aircraft, List[str]]] = []

        for aircraft in self.aircraft.values():
            rules: List[str] = []

            if aircraft.type != flight.required_aircraft_type:
                continue
            rules.append("R1_aircraft_type_match")

            route_key = f"{flight.origin}-{flight.destination}"
            if route_key not in aircraft.qualified_routes:
                continue
            rules.append("R2_route_qualification")

            if self._overlaps_maintenance(aircraft, flight.departure, flight.arrival):
                continue
            rules.append("R3_no_maintenance_overlap")

            if not self._is_resource_available(
                aircraft_timeline[aircraft.id],
                flight.departure,
                flight.arrival,
                min_turnaround=timedelta(minutes=45),
            ):
                continue
            rules.append("R4_turnaround_and_overlap")

            positioning_penalty = 0 if aircraft.base_airport == flight.origin else 15
            utilization_penalty = len(aircraft_timeline[aircraft.id]) * 2
            score = positioning_penalty + utilization_penalty
            rules.append("R5_lowest_penalty_selection")
            candidates.append((score, aircraft, rules))

        if not candidates:
            return None, ["R1-R5_failed_no_candidate"]

        candidates.sort(key=lambda x: x[0])
        _, chosen, chosen_rules = candidates[0]
        return chosen, chosen_rules

    def _choose_crew(
        self,
        flight: Flight,
        aircraft: Aircraft,
        crew_timeline: Dict[str, List[Tuple[datetime, datetime, str]]],
    ) -> Tuple[Optional[Crew], List[str]]:
        route_key = f"{flight.origin}-{flight.destination}"
        flight_duration_hours = (flight.arrival - flight.departure).total_seconds() / 3600
        candidates: List[Tuple[int, Crew, List[str]]] = []

        for crew in self.crews.values():
            rules: List[str] = []

            if aircraft.type not in crew.qualifications:
                continue
            rules.append("R6_crew_aircraft_qualification")

            if not self._is_resource_available(
                crew_timeline[crew.id],
                flight.departure,
                flight.arrival,
                min_turnaround=timedelta(minutes=30),
            ):
                continue
            rules.append("R7_crew_no_overlap")

            projected_hours = self._assigned_hours(crew_timeline[crew.id]) + flight_duration_hours
            if projected_hours > crew.max_duty_hours:
                continue
            rules.append("R8_crew_duty_limit")

            route_bonus = 0 if route_key.endswith("DEL") else 1
            balance_penalty = len(crew_timeline[crew.id])
            score = route_bonus + balance_penalty
            rules.append("R9_crew_balance_selection")
            candidates.append((score, crew, rules))

        if not candidates:
            return None, ["R6-R9_failed_no_candidate"]

        candidates.sort(key=lambda x: x[0])
        _, chosen, chosen_rules = candidates[0]
        return chosen, chosen_rules

    def allocate_cargo(self) -> None:
        orders = sorted(
            self.cargo_orders.values(),
            key=lambda x: (PRIORITY_MAP.get(x.priority, 99), x.deadline),
        )

        for order in orders:
            if order.priority in {"emergency", "perishable"}:
                priority_rule = "R10_high_priority_first"
            else:
                priority_rule = "R11_standard_priority_queue"

            candidates: List[Tuple[int, Flight, List[str]]] = []
            for flight in self.flights.values():
                rules: List[str] = [priority_rule]

                if not flight.assigned_aircraft:
                    continue

                if flight.origin != order.origin or flight.destination != order.destination:
                    continue
                rules.append("R12_route_match_for_cargo")

                if flight.arrival > order.deadline:
                    continue
                rules.append("R13_deadline_respected")

                aircraft = self.aircraft[flight.assigned_aircraft]
                remaining = aircraft.capacity_kg - flight.cargo_weight_kg
                if remaining < order.weight_kg:
                    continue
                rules.append("R14_capacity_check")

                slack_minutes = int((order.deadline - flight.arrival).total_seconds() / 60)
                capacity_after = remaining - order.weight_kg
                score = slack_minutes + capacity_after // 100
                rules.append("R15_minimize_deadline_slack_waste")
                candidates.append((score, flight, rules))

            if not candidates:
                self.unassigned_cargo.append(order.id)
                self.decisions.append(
                    Decision(
                        step="cargo_assignment",
                        entity_id=order.id,
                        outcome="rejected_no_feasible_flight",
                        rules_fired=[priority_rule, "R12-R15_failed_no_candidate"],
                    )
                )
                continue

            candidates.sort(key=lambda x: x[0])
            _, selected, selected_rules = candidates[0]
            selected.cargo_manifest.append(order.id)
            selected.cargo_weight_kg += order.weight_kg
            order.assigned_flight = selected.id
            self.decisions.append(
                Decision(
                    step="cargo_assignment",
                    entity_id=order.id,
                    outcome=f"assigned_flight_{selected.id}",
                    rules_fired=selected_rules,
                )
            )

    def build_report(self) -> Dict:
        assigned_flights = [f for f in self.flights.values() if f.assigned_aircraft and f.assigned_crew]
        assigned_cargo = [c for c in self.cargo_orders.values() if c.assigned_flight]

        total_flights = len(self.flights)
        total_cargo = len(self.cargo_orders)
        total_capacity = sum(self.aircraft[f.assigned_aircraft].capacity_kg for f in assigned_flights)
        total_loaded = sum(f.cargo_weight_kg for f in assigned_flights)

        report = {
            "summary": {
                "total_flights": total_flights,
                "assigned_flights": len(assigned_flights),
                "flight_feasibility_rate": round(len(assigned_flights) / total_flights * 100, 2) if total_flights else 0,
                "total_cargo_orders": total_cargo,
                "assigned_cargo_orders": len(assigned_cargo),
                "cargo_fulfillment_rate": round(len(assigned_cargo) / total_cargo * 100, 2) if total_cargo else 0,
                "capacity_utilization_rate": round(total_loaded / total_capacity * 100, 2) if total_capacity else 0,
                "unassigned_flights": self.unassigned_flights,
                "unassigned_cargo": self.unassigned_cargo,
            },
            "flight_schedule": [
                {
                    "flight_id": f.id,
                    "route": f"{f.origin}-{f.destination}",
                    "departure": f.departure.strftime(TIME_FMT),
                    "arrival": f.arrival.strftime(TIME_FMT),
                    "aircraft": f.assigned_aircraft,
                    "crew": f.assigned_crew,
                    "cargo_manifest": f.cargo_manifest,
                    "cargo_weight_kg": f.cargo_weight_kg,
                }
                for f in sorted(self.flights.values(), key=lambda x: x.departure)
            ],
            "cargo_assignments": [
                {
                    "cargo_id": c.id,
                    "priority": c.priority,
                    "route": f"{c.origin}-{c.destination}",
                    "weight_kg": c.weight_kg,
                    "deadline": c.deadline.strftime(TIME_FMT),
                    "assigned_flight": c.assigned_flight,
                }
                for c in sorted(
                    self.cargo_orders.values(),
                    key=lambda x: (PRIORITY_MAP.get(x.priority, 99), x.deadline),
                )
            ],
            "decision_trace": [
                {
                    "step": d.step,
                    "entity_id": d.entity_id,
                    "outcome": d.outcome,
                    "rules_fired": d.rules_fired,
                }
                for d in self.decisions
            ],
        }
        return report

    @staticmethod
    def _overlaps_maintenance(aircraft: Aircraft, start: datetime, end: datetime) -> bool:
        for m_start, m_end in aircraft.maintenance_windows:
            if start < m_end and end > m_start:
                return True
        return False

    @staticmethod
    def _is_resource_available(
        intervals: List[Tuple[datetime, datetime, str]],
        start: datetime,
        end: datetime,
        min_turnaround: timedelta,
    ) -> bool:
        for i_start, i_end, _ in intervals:
            if start < i_end + min_turnaround and end > i_start - min_turnaround:
                return False
        return True

    @staticmethod
    def _assigned_hours(intervals: List[Tuple[datetime, datetime, str]]) -> float:
        total_seconds = sum((end - start).total_seconds() for start, end, _ in intervals)
        return total_seconds / 3600


def print_console_report(report: Dict) -> None:
    summary = report["summary"]
    print("=" * 100)
    print("AIRLINE + CARGO EXPERT SYSTEM REPORT")
    print("=" * 100)

    summary_rows = [
        ["Total Flights", str(summary["total_flights"])],
        ["Assigned Flights", str(summary["assigned_flights"])],
        ["Flight Feasibility", f"{summary['flight_feasibility_rate']}%"],
        ["Total Cargo Orders", str(summary["total_cargo_orders"])],
        ["Assigned Cargo", str(summary["assigned_cargo_orders"])],
        ["Cargo Fulfillment", f"{summary['cargo_fulfillment_rate']}%"],
        ["Capacity Utilization", f"{summary['capacity_utilization_rate']}%"],
        ["Unassigned Flights", ", ".join(summary["unassigned_flights"]) or "None"],
        ["Unassigned Cargo", ", ".join(summary["unassigned_cargo"]) or "None"],
    ]
    print(render_text_table(["Metric", "Value"], summary_rows))

    print("\nFLIGHT ASSIGNMENTS")
    print("-" * 100)
    flight_rows = []
    for f in report["flight_schedule"]:
        flight_rows.append(
            [
                f["flight_id"],
                f["route"],
                f["departure"],
                f["arrival"],
                f["aircraft"] or "UNASSIGNED",
                f["crew"] or "UNASSIGNED",
                str(f["cargo_weight_kg"]),
                str(len(f["cargo_manifest"])),
            ]
        )
    print(
        render_text_table(
            ["Flight", "Route", "Departure", "Arrival", "Aircraft", "Crew", "Cargo Kg", "Cargo Items"],
            flight_rows,
        )
    )

    print("\nDECISION TRACE (first 12)")
    print("-" * 100)
    decision_rows = []
    for d in report["decision_trace"][:12]:
        decision_rows.append([d["step"], d["entity_id"], d["outcome"], ",".join(d["rules_fired"][:3]) + "..."])
    print(render_text_table(["Step", "Entity", "Outcome", "Rules (sample)"], decision_rows))


def render_text_table(headers: List[str], rows: List[List[str]]) -> str:
    if not rows:
        return "No data available."

    str_rows = [[str(cell) for cell in row] for row in rows]
    widths = [len(h) for h in headers]
    for row in str_rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))

    def line(sep: str = "-") -> str:
        return "+" + "+".join(sep * (w + 2) for w in widths) + "+"

    def format_row(row: List[str]) -> str:
        return "| " + " | ".join(cell.ljust(widths[i]) for i, cell in enumerate(row)) + " |"

    output = [line("="), format_row(headers), line("=")]
    for row in str_rows:
        output.append(format_row(row))
        output.append(line("-"))
    return "\n".join(output)


def save_json_report(report: Dict, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_markdown_report(report: Dict, output_path: Path) -> None:
        summary = report["summary"]
        lines = [
                "# Airline + Cargo Scheduling Expert System Report",
                "",
                "## KPI Summary",
                "",
                "| Metric | Value |",
                "|---|---|",
                f"| Total Flights | {summary['total_flights']} |",
                f"| Assigned Flights | {summary['assigned_flights']} |",
                f"| Flight Feasibility | {summary['flight_feasibility_rate']}% |",
                f"| Total Cargo Orders | {summary['total_cargo_orders']} |",
                f"| Assigned Cargo Orders | {summary['assigned_cargo_orders']} |",
                f"| Cargo Fulfillment | {summary['cargo_fulfillment_rate']}% |",
                f"| Capacity Utilization | {summary['capacity_utilization_rate']}% |",
                f"| Unassigned Flights | {', '.join(summary['unassigned_flights']) or 'None'} |",
                f"| Unassigned Cargo | {', '.join(summary['unassigned_cargo']) or 'None'} |",
                "",
                "## Flight Schedule",
                "",
                "| Flight | Route | Departure | Arrival | Aircraft | Crew | Cargo Kg | Cargo Items |",
                "|---|---|---|---|---|---|---:|---:|",
        ]

        for f in report["flight_schedule"]:
                lines.append(
                        "| "
                        + " | ".join(
                                [
                                        str(f["flight_id"]),
                                        str(f["route"]),
                                        str(f["departure"]),
                                        str(f["arrival"]),
                                        str(f["aircraft"] or "UNASSIGNED"),
                                        str(f["crew"] or "UNASSIGNED"),
                                        str(f["cargo_weight_kg"]),
                                        str(len(f["cargo_manifest"])),
                                ]
                        )
                        + " |"
                )

        lines.extend(
                [
                        "",
                        "## Decision Trace (first 20)",
                        "",
                        "| Step | Entity | Outcome | Rules Fired |",
                        "|---|---|---|---|",
                ]
        )
        for d in report["decision_trace"][:20]:
                rules = ", ".join(d["rules_fired"])
                lines.append(f"| {d['step']} | {d['entity_id']} | {d['outcome']} | {rules} |")

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("\n".join(lines), encoding="utf-8")


def save_html_report(report: Dict, output_path: Path) -> None:
        summary = report["summary"]

        def _row(cells: List[str], tag: str = "td") -> str:
                return "<tr>" + "".join(f"<{tag}>{cell}</{tag}>" for cell in cells) + "</tr>"

        summary_rows = "".join(
                _row([metric, value])
                for metric, value in [
                        ("Total Flights", str(summary["total_flights"])),
                        ("Assigned Flights", str(summary["assigned_flights"])),
                        ("Flight Feasibility", f"{summary['flight_feasibility_rate']}%"),
                        ("Total Cargo Orders", str(summary["total_cargo_orders"])),
                        ("Assigned Cargo Orders", str(summary["assigned_cargo_orders"])),
                        ("Cargo Fulfillment", f"{summary['cargo_fulfillment_rate']}%"),
                        ("Capacity Utilization", f"{summary['capacity_utilization_rate']}%"),
                        ("Unassigned Flights", ", ".join(summary["unassigned_flights"]) or "None"),
                        ("Unassigned Cargo", ", ".join(summary["unassigned_cargo"]) or "None"),
                ]
        )

        flight_rows = "".join(
                _row(
                        [
                                str(f["flight_id"]),
                                str(f["route"]),
                                str(f["departure"]),
                                str(f["arrival"]),
                                str(f["aircraft"] or "UNASSIGNED"),
                                str(f["crew"] or "UNASSIGNED"),
                                str(f["cargo_weight_kg"]),
                                str(len(f["cargo_manifest"])),
                        ]
                )
                for f in report["flight_schedule"]
        )

        decision_rows = "".join(
                _row(
                        [
                                str(d["step"]),
                                str(d["entity_id"]),
                                str(d["outcome"]),
                                ", ".join(d["rules_fired"]),
                        ]
                )
                for d in report["decision_trace"][:25]
        )

        html = f"""<!doctype html>
<html lang=\"en\"> 
<head>
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    <title>Airline and Cargo Scheduling Report</title>
    <style>
        :root {{ --bg:#f6f7fb; --card:#ffffff; --ink:#102542; --muted:#51627a; --accent:#1d8f6e; --line:#dfe5ef; }}
        body {{ margin:0; font-family:Segoe UI, Tahoma, sans-serif; background:linear-gradient(135deg,#eef2f8 0%,#f9fbff 100%); color:var(--ink); }}
        .wrap {{ max-width:1100px; margin:32px auto; padding:0 16px; }}
        .hero {{ background:var(--card); border:1px solid var(--line); border-radius:14px; padding:20px; box-shadow:0 10px 28px rgba(16,37,66,0.08); }}
        h1 {{ margin:0 0 8px 0; font-size:28px; }}
        p {{ margin:0; color:var(--muted); }}
        .grid {{ display:grid; grid-template-columns:1fr; gap:14px; margin-top:16px; }}
        .panel {{ background:var(--card); border:1px solid var(--line); border-radius:14px; padding:14px; box-shadow:0 6px 18px rgba(16,37,66,0.06); overflow:auto; }}
        table {{ width:100%; border-collapse:collapse; font-size:14px; }}
        th, td {{ border-bottom:1px solid var(--line); text-align:left; padding:10px; vertical-align:top; }}
        th {{ background:#f1f4fa; color:#20324e; position:sticky; top:0; }}
        .badge {{ display:inline-block; background:#e9f8f3; color:var(--accent); border:1px solid #bce7d9; border-radius:999px; padding:3px 10px; font-weight:600; }}
        @media (min-width: 860px) {{ .grid {{ grid-template-columns: 1fr 1fr; }} .panel.full {{ grid-column:1 / -1; }} }}
    </style>
</head>
<body>
    <div class=\"wrap\">
        <section class=\"hero\">
            <h1>Airline + Cargo Expert System Report</h1>
            <p>Rule-driven schedule with explainable decision trace</p>
            <div style=\"margin-top:10px;\"><span class=\"badge\">Flight Feasibility: {summary['flight_feasibility_rate']}%</span> <span class=\"badge\">Cargo Fulfillment: {summary['cargo_fulfillment_rate']}%</span> <span class=\"badge\">Capacity Utilization: {summary['capacity_utilization_rate']}%</span></div>
        </section>

        <section class=\"grid\">
            <article class=\"panel\">
                <h3>KPI Summary</h3>
                <table>
                    <thead>{_row(["Metric", "Value"], "th")}</thead>
                    <tbody>{summary_rows}</tbody>
                </table>
            </article>

            <article class=\"panel\">
                <h3>Decision Trace (first 25)</h3>
                <table>
                    <thead>{_row(["Step", "Entity", "Outcome", "Rules Fired"], "th")}</thead>
                    <tbody>{decision_rows}</tbody>
                </table>
            </article>

            <article class=\"panel full\">
                <h3>Flight Schedule</h3>
                <table>
                    <thead>{_row(["Flight", "Route", "Departure", "Arrival", "Aircraft", "Crew", "Cargo Kg", "Cargo Items"], "th")}</thead>
                    <tbody>{flight_rows}</tbody>
                </table>
            </article>
        </section>
    </div>
</body>
</html>
"""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(html, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Expert system prototype for airline and cargo scheduling."
    )
    parser.add_argument(
        "--data",
        default="data/sample_data.json",
        help="Path to input JSON dataset.",
    )
    parser.add_argument(
        "--out",
        default="outputs/schedule_report.json",
        help="Path to save generated report JSON.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data_path = Path(args.data)
    out_path = Path(args.out)

    if not data_path.exists():
        raise FileNotFoundError(f"Dataset not found: {data_path}")

    raw_data = json.loads(data_path.read_text(encoding="utf-8"))
    scheduler = ExpertScheduler(raw_data)
    report = scheduler.run()

    print_console_report(report)
    save_json_report(report, out_path)
    md_path = out_path.with_suffix(".md")
    html_path = out_path.with_suffix(".html")
    save_markdown_report(report, md_path)
    save_html_report(report, html_path)
    print("-" * 78)
    print(f"Detailed JSON report saved to: {out_path}")
    print(f"Presentation Markdown report saved to: {md_path}")
    print(f"Presentation HTML report saved to: {html_path}")


if __name__ == "__main__":
    main()
