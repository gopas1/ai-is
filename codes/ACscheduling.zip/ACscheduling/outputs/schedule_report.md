# Airline + Cargo Scheduling Expert System Report

## KPI Summary

| Metric | Value |
|---|---|
| Total Flights | 10 |
| Assigned Flights | 8 |
| Flight Feasibility | 80.0% |
| Total Cargo Orders | 20 |
| Assigned Cargo Orders | 18 |
| Cargo Fulfillment | 90.0% |
| Capacity Utilization | 33.64% |
| Unassigned Flights | F105, F108 |
| Unassigned Cargo | C015, C006 |

## Flight Schedule

| Flight | Route | Departure | Arrival | Aircraft | Crew | Cargo Kg | Cargo Items |
|---|---|---|---|---|---|---:|---:|
| F101 | DEL-BOM | 2026-04-21 06:30 | 2026-04-21 08:40 | AC101 | CR1 | 1400 | 1 |
| F103 | DEL-HYD | 2026-04-21 07:15 | 2026-04-21 09:20 | AC201 | CR2 | 12400 | 3 |
| F102 | BOM-DEL | 2026-04-21 09:45 | 2026-04-21 11:55 | AC102 | CR4 | 9700 | 3 |
| F104 | HYD-DEL | 2026-04-21 10:15 | 2026-04-21 12:25 | AC202 | CR3 | 6900 | 3 |
| F109 | BOM-HYD | 2026-04-21 13:10 | 2026-04-21 15:00 | AC102 | CR6 | 5200 | 2 |
| F105 | DEL-BLR | 2026-04-21 14:00 | 2026-04-21 16:20 | UNASSIGNED | UNASSIGNED | 0 | 0 |
| F107 | DEL-BOM | 2026-04-21 15:10 | 2026-04-21 17:20 | AC201 | CR5 | 9200 | 3 |
| F110 | HYD-BOM | 2026-04-21 16:00 | 2026-04-21 17:50 | AC102 | CR1 | 2600 | 1 |
| F106 | BLR-DEL | 2026-04-21 17:20 | 2026-04-21 19:40 | AC101 | CR2 | 3900 | 2 |
| F108 | BOM-DEL | 2026-04-21 18:15 | 2026-04-21 20:25 | UNASSIGNED | UNASSIGNED | 0 | 0 |

## Decision Trace (first 20)

| Step | Entity | Outcome | Rules Fired |
|---|---|---|---|
| flight_assignment | F101 | assigned_aircraft_AC101_crew_CR1 | R1_aircraft_type_match, R2_route_qualification, R3_no_maintenance_overlap, R4_turnaround_and_overlap, R5_lowest_penalty_selection, R6_crew_aircraft_qualification, R7_crew_no_overlap, R8_crew_duty_limit, R9_crew_balance_selection |
| flight_assignment | F103 | assigned_aircraft_AC201_crew_CR2 | R1_aircraft_type_match, R2_route_qualification, R3_no_maintenance_overlap, R4_turnaround_and_overlap, R5_lowest_penalty_selection, R6_crew_aircraft_qualification, R7_crew_no_overlap, R8_crew_duty_limit, R9_crew_balance_selection |
| flight_assignment | F102 | assigned_aircraft_AC102_crew_CR4 | R1_aircraft_type_match, R2_route_qualification, R3_no_maintenance_overlap, R4_turnaround_and_overlap, R5_lowest_penalty_selection, R6_crew_aircraft_qualification, R7_crew_no_overlap, R8_crew_duty_limit, R9_crew_balance_selection |
| flight_assignment | F104 | assigned_aircraft_AC202_crew_CR3 | R1_aircraft_type_match, R2_route_qualification, R3_no_maintenance_overlap, R4_turnaround_and_overlap, R5_lowest_penalty_selection, R6_crew_aircraft_qualification, R7_crew_no_overlap, R8_crew_duty_limit, R9_crew_balance_selection |
| flight_assignment | F109 | assigned_aircraft_AC102_crew_CR6 | R1_aircraft_type_match, R2_route_qualification, R3_no_maintenance_overlap, R4_turnaround_and_overlap, R5_lowest_penalty_selection, R6_crew_aircraft_qualification, R7_crew_no_overlap, R8_crew_duty_limit, R9_crew_balance_selection |
| flight_assignment | F105 | rejected_no_aircraft | R1-R5_failed_no_candidate |
| flight_assignment | F107 | assigned_aircraft_AC201_crew_CR5 | R1_aircraft_type_match, R2_route_qualification, R3_no_maintenance_overlap, R4_turnaround_and_overlap, R5_lowest_penalty_selection, R6_crew_aircraft_qualification, R7_crew_no_overlap, R8_crew_duty_limit, R9_crew_balance_selection |
| flight_assignment | F110 | assigned_aircraft_AC102_crew_CR1 | R1_aircraft_type_match, R2_route_qualification, R3_no_maintenance_overlap, R4_turnaround_and_overlap, R5_lowest_penalty_selection, R6_crew_aircraft_qualification, R7_crew_no_overlap, R8_crew_duty_limit, R9_crew_balance_selection |
| flight_assignment | F106 | assigned_aircraft_AC101_crew_CR2 | R1_aircraft_type_match, R2_route_qualification, R3_no_maintenance_overlap, R4_turnaround_and_overlap, R5_lowest_penalty_selection, R6_crew_aircraft_qualification, R7_crew_no_overlap, R8_crew_duty_limit, R9_crew_balance_selection |
| flight_assignment | F108 | rejected_no_aircraft | R1-R5_failed_no_candidate |
| cargo_assignment | C001 | assigned_flight_F101 | R10_high_priority_first, R12_route_match_for_cargo, R13_deadline_respected, R14_capacity_check, R15_minimize_deadline_slack_waste |
| cargo_assignment | C012 | assigned_flight_F103 | R10_high_priority_first, R12_route_match_for_cargo, R13_deadline_respected, R14_capacity_check, R15_minimize_deadline_slack_waste |
| cargo_assignment | C017 | assigned_flight_F102 | R10_high_priority_first, R12_route_match_for_cargo, R13_deadline_respected, R14_capacity_check, R15_minimize_deadline_slack_waste |
| cargo_assignment | C009 | assigned_flight_F102 | R10_high_priority_first, R12_route_match_for_cargo, R13_deadline_respected, R14_capacity_check, R15_minimize_deadline_slack_waste |
| cargo_assignment | C005 | assigned_flight_F104 | R10_high_priority_first, R12_route_match_for_cargo, R13_deadline_respected, R14_capacity_check, R15_minimize_deadline_slack_waste |
| cargo_assignment | C020 | assigned_flight_F109 | R10_high_priority_first, R12_route_match_for_cargo, R13_deadline_respected, R14_capacity_check, R15_minimize_deadline_slack_waste |
| cargo_assignment | C002 | assigned_flight_F107 | R10_high_priority_first, R12_route_match_for_cargo, R13_deadline_respected, R14_capacity_check, R15_minimize_deadline_slack_waste |
| cargo_assignment | C015 | rejected_no_feasible_flight | R10_high_priority_first, R12-R15_failed_no_candidate |
| cargo_assignment | C004 | assigned_flight_F103 | R11_standard_priority_queue, R12_route_match_for_cargo, R13_deadline_respected, R14_capacity_check, R15_minimize_deadline_slack_waste |
| cargo_assignment | C019 | assigned_flight_F104 | R11_standard_priority_queue, R12_route_match_for_cargo, R13_deadline_respected, R14_capacity_check, R15_minimize_deadline_slack_waste |