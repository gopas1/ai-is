# AI Mini Project Report

## Title
Expert System for Airline and Cargo Scheduling

## 1. Abstract
This project presents a rule-based expert system that schedules airline flights and allocates cargo using operational constraints and priority-driven business rules. The system applies forward-chaining style rule execution to assign aircraft, crew, and cargo while satisfying hard constraints such as maintenance windows, turnaround times, crew duty limits, route qualification, capacity limits, and cargo deadlines. The output includes a machine-readable report and transparent rule trace for auditability.

## 2. Problem Statement
Airline scheduling and cargo assignment involve multiple interdependent constraints. Manual planning is error-prone and does not scale. The aim is to create an explainable AI system that generates feasible daily schedules and prioritizes urgent cargo shipments.

## 3. Objectives
- Build an expert system with explicit if-then production rules.
- Generate feasible assignments for flights (aircraft + crew).
- Allocate cargo to flights based on route, deadline, and capacity.
- Provide explainability through decision traces.
- Evaluate performance using feasibility and fulfillment KPIs.

## 4. Scope and Assumptions
- Single-day operational window.
- Fixed set of flights, aircraft, crew, and cargo orders.
- No weather disruptions in this prototype.
- Deterministic rule-based scheduling.

## 5. Methodology
### 5.1 Knowledge Base
The knowledge base stores domain facts:
- Aircraft: type, route qualifications, maintenance slots, capacity.
- Crew: aircraft qualifications, maximum duty hours.
- Flights: routes, departure/arrival times, required aircraft type.
- Cargo: route, weight, deadline, priority class.

### 5.2 Inference and Rule Execution
The system applies rule-driven filtering and scoring:
- Flight phase: select feasible aircraft and crew.
- Cargo phase: assign cargo by priority and operational feasibility.
- Decision logs capture all fired rules.

### 5.3 Rule Groups
- Flight rules R1-R9.
- Cargo rules R10-R15.

## 6. System Design
Input Data -> Expert Scheduler -> Flight Assignment Engine -> Cargo Allocation Engine -> KPI + Decision Trace Report

## 7. Implementation
Language: Python 3
Core file: main.py
Dataset: data/sample_data.json
Output report: outputs/schedule_report.json

## 8. Experimental Result (Sample Run)
- Flight Feasibility Rate: 80.0%
- Cargo Fulfillment Rate: 90.0%
- Capacity Utilization: 33.64%
- Unassigned Flights: F105, F108
- Unassigned Cargo: C015, C006

## 9. Why this is an AI Expert System
- Uses formal knowledge representation (facts + rules).
- Uses inference-style rule application for decision making.
- Produces explainable outcomes (rule trace), unlike black-box models.

## 10. Limitations
- Current prototype uses static, single-day scheduling.
- No disruption handling (weather, sudden maintenance, cancellations).
- No global optimization solver for absolute best schedule.

## 11. Future Enhancements
- Add real-time rescheduling module.
- Integrate optimization (MILP/metaheuristic) for cost minimization.
- Add ML demand forecasting for cargo planning.
- Build dashboard UI for planners.

## 12. Conclusion
The developed prototype demonstrates a practical and explainable expert system for airline and cargo scheduling. It enforces operational constraints, prioritizes critical cargo, and generates measurable KPIs, making it suitable for AI academic submission and further real-world extension.
