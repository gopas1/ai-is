#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

// --- AES 128 Standard Tables ---
const unsigned char sbox[256] = {
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16 
};

const unsigned char inv_sbox[256] = {
    0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
    0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
    0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
    0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
    0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
    0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
    0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
    0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
    0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
    0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
    0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
    0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
    0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
    0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
    0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
    0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d
};

const unsigned char Rcon[11] = {
    0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36
};

// --- AES Core Functions ---

// Galois Field Multiplication
unsigned char GMul(unsigned char a, unsigned char b) {
    unsigned char p = 0;
    for (int counter = 0; counter < 8; counter++) {
        if ((b & 1) != 0) p ^= a;
        bool hi_bit_set = (a & 0x80) != 0;
        a <<= 1;
        if (hi_bit_set) a ^= 0x1B; // AES polynomial
        b >>= 1;
    }
    return p;
}

void SubBytes(unsigned char state[4][4]) {
    for(int r=0; r<4; r++) for(int c=0; c<4; c++) state[r][c] = sbox[state[r][c]];
}
void InvSubBytes(unsigned char state[4][4]) {
    for(int r=0; r<4; r++) for(int c=0; c<4; c++) state[r][c] = inv_sbox[state[r][c]];
}

void ShiftRows(unsigned char state[4][4]) {
    unsigned char temp;
    // Row 1: Left shift by 1
    temp = state[1][0]; state[1][0] = state[1][1]; state[1][1] = state[1][2]; state[1][2] = state[1][3]; state[1][3] = temp;
    // Row 2: Left shift by 2
    temp = state[2][0]; state[2][0] = state[2][2]; state[2][2] = temp; temp = state[2][1]; state[2][1] = state[2][3]; state[2][3] = temp;
    // Row 3: Left shift by 3 (Right shift by 1)
    temp = state[3][3]; state[3][3] = state[3][2]; state[3][2] = state[3][1]; state[3][1] = state[3][0]; state[3][0] = temp;
}

void InvShiftRows(unsigned char state[4][4]) {
    unsigned char temp;
    // Row 1: Right shift by 1
    temp = state[1][3]; state[1][3] = state[1][2]; state[1][2] = state[1][1]; state[1][1] = state[1][0]; state[1][0] = temp;
    // Row 2: Right shift by 2
    temp = state[2][0]; state[2][0] = state[2][2]; state[2][2] = temp; temp = state[2][1]; state[2][1] = state[2][3]; state[2][3] = temp;
    // Row 3: Right shift by 3 (Left shift by 1)
    temp = state[3][0]; state[3][0] = state[3][1]; state[3][1] = state[3][2]; state[3][2] = state[3][3]; state[3][3] = temp;
}

void MixColumns(unsigned char state[4][4]) {
    unsigned char tmp[4];
    for (int c = 0; c < 4; c++) {
        for(int i=0; i<4; i++) tmp[i] = state[i][c];
        state[0][c] = GMul(0x02, tmp[0]) ^ GMul(0x03, tmp[1]) ^ tmp[2] ^ tmp[3];
        state[1][c] = tmp[0] ^ GMul(0x02, tmp[1]) ^ GMul(0x03, tmp[2]) ^ tmp[3];
        state[2][c] = tmp[0] ^ tmp[1] ^ GMul(0x02, tmp[2]) ^ GMul(0x03, tmp[3]);
        state[3][c] = GMul(0x03, tmp[0]) ^ tmp[1] ^ tmp[2] ^ GMul(0x02, tmp[3]);
    }
}

void InvMixColumns(unsigned char state[4][4]) {
    unsigned char tmp[4];
    for (int c = 0; c < 4; c++) {
        for(int i=0; i<4; i++) tmp[i] = state[i][c];
        state[0][c] = GMul(0x0e, tmp[0]) ^ GMul(0x0b, tmp[1]) ^ GMul(0x0d, tmp[2]) ^ GMul(0x09, tmp[3]);
        state[1][c] = GMul(0x09, tmp[0]) ^ GMul(0x0e, tmp[1]) ^ GMul(0x0b, tmp[2]) ^ GMul(0x0d, tmp[3]);
        state[2][c] = GMul(0x0d, tmp[0]) ^ GMul(0x09, tmp[1]) ^ GMul(0x0e, tmp[2]) ^ GMul(0x0b, tmp[3]);
        state[3][c] = GMul(0x0b, tmp[0]) ^ GMul(0x0d, tmp[1]) ^ GMul(0x09, tmp[2]) ^ GMul(0x0e, tmp[3]);
    }
}

void KeyExpansion(unsigned char key[16], unsigned char RoundKey[176]) {
    for (int i = 0; i < 16; i++) RoundKey[i] = key[i];
    
    int bytesGenerated = 16;
    int rconIteration = 1;
    unsigned char temp[4];

    while (bytesGenerated < 176) {
        for (int i = 0; i < 4; i++) temp[i] = RoundKey[i + bytesGenerated - 4];
        
        if (bytesGenerated % 16 == 0) {
            unsigned char t = temp[0]; temp[0] = temp[1]; temp[1] = temp[2]; temp[2] = temp[3]; temp[3] = t;
            for (int i = 0; i < 4; i++) temp[i] = sbox[temp[i]];
            temp[0] ^= Rcon[rconIteration++];
        }
        
        for (int i = 0; i < 4; i++) RoundKey[bytesGenerated] = RoundKey[bytesGenerated - 16] ^ temp[i], bytesGenerated++;
    }
}

void AddRoundKey(unsigned char state[4][4], unsigned char RoundKey[176], int round) {
    for (int c = 0; c < 4; c++) {
        for (int r = 0; r < 4; r++) {
            state[r][c] ^= RoundKey[round * 16 + (c * 4 + r)];
        }
    }
}

// AES-128 Encryption & Decryption wrappers
vector<unsigned char> aes_encrypt(vector<unsigned char> pt, unsigned char RoundKey[176]) {
    unsigned char state[4][4];
    for (int i = 0; i < 16; i++) state[i % 4][i / 4] = pt[i];

    AddRoundKey(state, RoundKey, 0);
    for (int round = 1; round < 10; round++) {
        SubBytes(state);
        ShiftRows(state);
        MixColumns(state);
        AddRoundKey(state, RoundKey, round);
    }
    SubBytes(state);
    ShiftRows(state);
    AddRoundKey(state, RoundKey, 10);

    vector<unsigned char> ct(16);
    for (int i = 0; i < 16; i++) ct[i] = state[i % 4][i / 4];
    return ct;
}

vector<unsigned char> aes_decrypt(vector<unsigned char> ct, unsigned char RoundKey[176]) {
    unsigned char state[4][4];
    for (int i = 0; i < 16; i++) state[i % 4][i / 4] = ct[i];

    AddRoundKey(state, RoundKey, 10);
    for (int round = 9; round > 0; round--) {
        InvShiftRows(state);
        InvSubBytes(state);
        AddRoundKey(state, RoundKey, round);
        InvMixColumns(state);
    }
    InvShiftRows(state);
    InvSubBytes(state);
    AddRoundKey(state, RoundKey, 0);

    vector<unsigned char> pt(16);
    for (int i = 0; i < 16; i++) pt[i] = state[i % 4][i / 4];
    return pt;
}

// --- Menu Logic Helpers ---

vector<unsigned char> hexToBytes(string hex) {
    vector<unsigned char> bytes;
    for (size_t i = 0; i < hex.length(); i += 2) {
        bytes.push_back((unsigned char)strtol(hex.substr(i, 2).c_str(), NULL, 16));
    }
    return bytes;
}

string bytesToHex(vector<unsigned char> bytes) {
    ostringstream oss;
    for (unsigned char c : bytes) oss << hex << setw(2) << setfill('0') << (int)c;
    return oss.str();
}

int main() {
    int choice;
    string text, key_str;

    while (true) {
        cout << "\n--- AES-128 Algorithm Menu ---\n";
        cout << "1. Encrypt (Text -> Ciphertext)\n";
        cout << "2. Decrypt (Ciphertext -> Text)\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 3) {
            cout << "Exiting...\n";
            break;
        } else if (choice == 1) {
            cout << "Enter Plaintext (up to 16 chars): ";
            cin.ignore(); getline(cin, text);
            cout << "Enter Key (up to 16 chars): ";
            getline(cin, key_str);

            while (text.length() < 16) text += ' '; // Padding
            while (key_str.length() < 16) key_str += ' ';

            vector<unsigned char> pt(text.begin(), text.begin() + 16);
            vector<unsigned char> key(key_str.begin(), key_str.begin() + 16);
            
            unsigned char RoundKey[176];
            KeyExpansion(key.data(), RoundKey);

            vector<unsigned char> ct = aes_encrypt(pt, RoundKey);
            cout << "Ciphertext (HEX): " << bytesToHex(ct) << endl;

        } else if (choice == 2) {
            cout << "Enter Ciphertext (32-char HEX): ";
            cin >> text;
            cout << "Enter Key (Text, up to 16 chars): ";
            cin.ignore(); getline(cin, key_str);

            while (key_str.length() < 16) key_str += ' ';
            vector<unsigned char> ct = hexToBytes(text);
            vector<unsigned char> key(key_str.begin(), key_str.begin() + 16);

            unsigned char RoundKey[176];
            KeyExpansion(key.data(), RoundKey);

            vector<unsigned char> pt = aes_decrypt(ct, RoundKey);
            string pt_str(pt.begin(), pt.end());
            cout << "Decrypted (Text): " << pt_str << endl;

        } else {
            cout << "Invalid choice. Please try again.\n";
        }
    }
    return 0;
}